# Progress: <topic>

**Current phase:** 1 (read and inventory)
**Next step:** ...

## Scenes
| Scene | Scripted | Voiced | Built | Sheet checked | Final render |
|---|---|---|---|---|---|

## Open questions and known problems
-

## Not verified
-

## How to continue
Read SKILL.md of the manim-video skill, then DECISIONS.md, COVERAGE.md, TOPIC_SHEET.md and this file.
`python <skill>/scripts/mv.py status .` shows what is voiced and rendered.
