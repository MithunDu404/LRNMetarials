# s02_dot_product.py: a worked dot product. Coverage: C003, C004.
# Pattern to copy: numbers computed and asserted at the top, one self.line / begin...end per narration line,
# every animation tied to a line, a section title at the start, clear_all() at the end.
import numpy as np
from mvkit import *


class S02DotProduct(LessonScene):
    def construct(self):
        a, b = np.array([1, 2, 3]), np.array([4, 0, -1])
        prods = a * b
        total = int(prods.sum())
        assert prods.tolist() == [4, 0, -3] and total == 1            # the source's result (slide 7)

        head = section_title("Dot product")
        ga = grid([a.tolist()], cell=0.8).move_to(UP * 1.2 + LEFT * 2.5)
        gb = signed_grid([b.tolist()], cell=0.8).move_to(UP * 1.2 + RIGHT * 2.5)
        self.line(1, FadeIn(head), FadeIn(ga), FadeIn(gb))             # "Here are two lists of three numbers."

        terms = MathTex(*[rf"{x} \times {y}" if y >= 0 else rf"{x} \times ({y})" for x, y in zip(a, b)],
                        font_size=40).arrange(RIGHT, buff=0.9).move_to(DOWN * 0.4)
        plus = VGroup(*[MathTex("+", font_size=40).move_to((l.get_right() + r.get_left()) / 2) for l, r in zip(terms, terms[1:])])
        self.begin(2)                                                  # "Multiply them pair by pair..."
        for k in range(3):
            self.at(0.15 + 0.27 * k)                                   # each pair lands as it is spoken
            box = VGroup(SurroundingRectangle(ga[k], color=LOOK_HERE, buff=0), SurroundingRectangle(gb[k], color=LOOK_HERE, buff=0))
            self.play(Create(box), Write(terms[k]), *([FadeIn(plus[k - 1])] if k else []), run_time=0.7)
            self.remove(box)
        self.end()

        result = MathTex("=", str(total), font_size=FORMULA_SIZE).move_to(DOWN * 1.9)
        result[1].set_color(RESULT)
        self.line(3, Write(result), run_time=1.2, gap=1.5)             # "...and add: the answer is one." then a hold
        self.clear_all()
