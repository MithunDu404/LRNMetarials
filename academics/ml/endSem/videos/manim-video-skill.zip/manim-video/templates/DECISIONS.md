# Decisions: <topic>

The user's answers to the questions, with the date. "default" means the recommended default was accepted.

| # | Question | Answer |
|---|---|---|
| a | Audience and level | |
| b | Language and tone | |
| c | Length and parts | |
| d | Depth / what gets more time | |
| e | Skip, merge, reorder, emphasise | |
| f | [added] examples allowed? | |
| g | Suspected source errors (one row each) | |
| h | Real images | |
| i | Voice (engine, name, speed) | |
| j | Title, title card, recap, quiz | |

## Later decisions
