# script.py: the narration, the only place it is edited. Then:  python <skill>/scripts/mv.py script <this folder>
# That writes script.json (read by the voice step) and SCRIPT_REVIEW.md (for the user to read and approve).
#
# One entry per scene, in video order. The key is the scene file name: scenes/<key>.py holds class CamelCase(<key>).
# Videos in parts: start keys with p1_, p2_ ...; `mv.py join` then makes one file per part.
# One tuple per narration line = one visual step:
#   (spoken text, planned visual, "coverage IDs", flag)
#   spoken text  a string, or (spoken, subtitle) when the ear and the eye need different text:
#                ("W two equals W one minus F, plus one.", "W2 = W1 - F + 1")
#   flag         "" from the source, A = not in the source (needs approval), FIX = corrects a source mistake
A, FIX = "added", "fix"
TITLE = "<video title>"

SCENES = {}

SCENES["s01_intro"] = [
    ("<A question the video answers.>", "Title card", "", A),
    ("<First idea, in plain words.>", "<what is on screen>", "C001"),
]
