# Topic Sheet: <topic>

Source: <path, or "researched: <links>">
Audience: <e.g. B.Tech 3rd-year students, first time seeing the topic>
Target length: <minutes>, parts: <1 / 2 / 3>
Voice: <kokoro af_heart 0.85 | sarvam shubh_en_narration en-IN 1.1>

## Role colours (max 5)
| Role | Concept in this topic |
|---|---|
| SUBJECT (greys) | |
| TOOL (YELLOW) | |
| RESULT (BLUE) | |
| POSITIVE / NEGATIVE (BLUE / RED) | |
| SECOND TOOL (TEAL_C) | |
| LEARNED (GREEN_C) | |
| CHANGE / ERROR (ORANGE) | |

## Symbol colours (one colour per symbol for the whole video; goes into scenes/topic.py)
| Symbol | Meaning | Colour |
|---|---|---|

## Scene plan
| # | Scene file | Coverage IDs | Step of the video shape | Main visual | ~Length |
|---|---|---|---|---|---|

## Numbers to verify (each gets an assert in its scene)
- <example>: <expected result from the source>

## Source mistakes found
- <location>: <what is wrong> → <what the video shows and says instead>

## Added content (not in the source; needs the user's approval)
- <scene>: <what and why>
