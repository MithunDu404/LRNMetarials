# topic.py: things shared by this video's scenes (symbol colours, the worked example's numbers, topic helpers).
# Scene files import it with:  from topic import *
import numpy as np
from mvkit import *

# One colour per symbol for the whole video (from TOPIC_SHEET.md). Use: formula(r"...", SYMBOLS)
SYMBOLS = {}
