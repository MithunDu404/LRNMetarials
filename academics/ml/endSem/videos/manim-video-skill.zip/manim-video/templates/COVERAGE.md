# Coverage: <topic>

Source: `source/<file>`. Every item below must be taught in the video. One row per item, in source order.
Status: `planned` → `scripted` → `done` (its scene is built and checked).

| ID | Source location | Type | Content (formulas in LaTeX, examples with all their numbers) | Scene | Status |
|---|---|---|---|---|---|
| C001 | §1 heading / slide 2 | definition | ... | s01_intro | planned |
