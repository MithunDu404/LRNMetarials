# mvkit.py: the shared look, narration timing and shape helpers for every manim-video scene.
# Scene files start with:  from mvkit import *      (render.py puts this folder on the import path)
import json
import os
import re
import shutil
import sys
from pathlib import Path

from manim import *

config.background_color = BLACK

# ---------------------------------------------------------------- colours and sizes (references/style.md)
INK, SOFT, LABEL, DIM, GUIDE, EMPTY = WHITE, GREY_A, GREY_B, GREY_C, GREY_D, GREY_E

TOOL        = YELLOW      # the thing acting on the data
RESULT      = BLUE        # what comes out
POS, NEG    = BLUE, RED   # sign of a value or weight
SECOND_TOOL = TEAL_C      # a second, different operation
LEARNED     = GREEN_C     # numbers found by training / the answer found
CHANGE      = ORANGE      # gradient, error, "how much to change"
LOOK_HERE   = YELLOW      # box around the current item

CELL, CELL_SMALL = 0.6, 0.45
NEURON_R = 0.18
TITLE_SIZE, BODY_SIZE, FORMULA_SIZE, LABEL_SIZE, CELL_NUM_SIZE = 40, 36, 48, 28, 26
SAFE = 0.5                # safe margin from every screen edge, in Manim units

HAS_LATEX = shutil.which("latex") is not None
HAS_PANGO = os.environ.get("MV_NO_PANGO") != "1"


def T(text, size=BODY_SIZE, color=SOFT):
    """Words on screen. Uses LaTeX (Computer Modern) when it is installed; otherwise plain Text with the
    LaTeX marks stripped (formulas then need MathTex, which always needs LaTeX)."""
    if HAS_LATEX:
        return Tex(text, font_size=size, color=color)
    assert HAS_PANGO, "neither LaTeX nor Pango is available: no way to draw text"
    return Text(re.sub(r"\\\\", "\n", text).replace("$", "").replace("\\", ""), font_size=size * 0.75, color=color)


# ---------------------------------------------------------------- narration-timed scene
class LessonScene(Scene):
    """A scene that plays the narration lines made by `mv.py voice` and times animations against them.

    The scene file <video>/scenes/<name>.py holds one class named CamelCase(<name>); its lines are
    <name>/l01, <name>/l02 ... in <video>/audio/voice.json.

        self.line(1, FadeIn(title))                 one line, one group of animations
        self.begin(2); self.play(...); self.at(0.5); self.play(...); self.end()
        self.reveal(3, [a, b, c])                   items appear one by one while line 3 is spoken
    """

    def setup(self):
        self.scene_file = Path(sys.modules[type(self).__module__].__file__).resolve()
        self.video_dir = self.scene_file.parents[1]
        self.voice = json.loads((self.video_dir / "audio" / "voice.json").read_text(encoding="utf-8"))
        self._line_n = 0

    def key(self, n):
        return f"{self.scene_file.stem}/l{n:02d}"

    def begin(self, n):
        """Start narration line n. Play animations, then call end()."""
        line = self.voice[self.key(n)]
        self.add_sound(str(self.video_dir / "audio" / f"{self.key(n)}.wav"))
        self.add_subcaption(line.get("sub") or line["text"], duration=line["seconds"])
        self._line_n = n
        self._line_start = self.renderer.time
        self._line_end = self._line_start + line["seconds"]

    def at(self, frac):
        """Hold until this fraction (0..1) of the current line has been spoken."""
        target = self._line_start + frac * (self._line_end - self._line_start)
        if target - self.renderer.time > 0.03:
            self.wait(target - self.renderer.time)

    def left(self):
        """Seconds of the current line still to be spoken."""
        return self._line_end - self.renderer.time

    def end(self, gap=0.35):
        """Hold until the current line has finished, plus a short breath. Fails if animations ran past it."""
        left = self._line_end - self.renderer.time
        assert left > -0.15, f"{self.key(self._line_n)}: animations ran {-left:.2f} s past the narration"
        self._check_margins()
        self.wait(max(left, 0) + gap)

    def line(self, n, *animations, run_time=1.5, gap=0.35):
        """One line with at most one group of animations."""
        self.begin(n)
        if animations:
            self.play(*animations, run_time=min(run_time, max(self.left() - 0.05, 0.3)))
        self.end(gap)

    def reveal(self, n, items, fracs=None, run_time=0.8, gap=0.35, anim=FadeIn):
        """Line n, with items appearing one by one at the given fractions of the line."""
        self.begin(n)
        fracs = fracs or [0.85 * i / len(items) for i in range(len(items))]
        for m, f in zip(items, fracs):
            self.at(f)
            self.play(anim(m), run_time=min(run_time, max(self.left() - 0.1, 0.3)))
        self.end(gap)

    def pause(self, seconds=1.5):
        """Silent hold after a key reveal."""
        self.wait(seconds)

    def clear_except(self, *keep, run_time=0.8):
        gone = [m for m in self.mobjects if m not in keep]
        if gone:
            self.play(*[FadeOut(m) for m in gone], run_time=run_time)

    def clear_all(self, run_time=0.8):
        """Every scene ends with this."""
        if self.mobjects:
            self.play(*[FadeOut(m) for m in self.mobjects], run_time=run_time)

    def title_card(self, n, title, subtitle=None, gap=0.6):
        """Line n over a centred title (and a smaller second line). Returns the group so it can be faded."""
        t = T(title, 56, INK)
        g = VGroup(t, T(subtitle, BODY_SIZE, LABEL)).arrange(DOWN, buff=0.45) if subtitle else VGroup(t)
        if g.width > 12.6:
            g.scale_to_fit_width(12.6)
        self.line(n, Write(t), *([FadeIn(g[1], shift=UP * 0.2)] if subtitle else []), run_time=1.5, gap=gap)
        return g

    def recap(self, title, points, size=32, first=1):
        """Recap screen: line `first` = title, then one line per point, then one closing line."""
        head = section_title(title)
        items = VGroup(*[T(p, size, SOFT) for p in points]).arrange(DOWN, buff=0.55, aligned_edge=LEFT)
        if items.width > 12.6:
            items.scale_to_fit_width(12.6)
        items.move_to(DOWN * 0.3)
        self.line(first, FadeIn(head), run_time=0.8)
        for k, item in enumerate(items):
            self.line(first + 1 + k, FadeIn(item, shift=UP * 0.2), run_time=0.9)
        self.line(first + 1 + len(points), gap=1.0)
        self.clear_all()

    def _check_margins(self):
        """Print a warning (collected by `mv.py scene`) for anything outside the safe area at the end of a line."""
        if type(self.camera).__name__ != "Camera":          # moving or 3D camera: the frame is not fixed
            return
        w, h = config.frame_width / 2 - SAFE + 0.03, config.frame_height / 2 - SAFE + 0.03
        for m in self.mobjects:
            if m.width == 0 and m.height == 0:
                continue
            l, r, b, t = m.get_left()[0], m.get_right()[0], m.get_bottom()[1], m.get_top()[1]
            if l < -w or r > w or b < -h or t > h:
                print(f"MV-WARN {self.key(self._line_n)}: {type(m).__name__} leaves the safe area "
                      f"(x {l:.2f}..{r:.2f}, y {b:.2f}..{t:.2f})", flush=True)


# ---------------------------------------------------------------- text helpers
def section_title(text):
    """Small title in the top-left corner with a thin underline."""
    t = T(text, TITLE_SIZE, INK).to_corner(UL, buff=SAFE)
    line = Line(t.get_corner(DL), t.get_corner(DR), stroke_width=1.5, color=DIM).shift(DOWN * 0.12)
    return VGroup(t, line)


def body(text, size=BODY_SIZE, color=SOFT):
    return T(text, size, color)


def bullet_lines(texts, size=BODY_SIZE, buff=0.5):
    """Short lines, left-aligned (at most 2-3 on screen at once)."""
    return VGroup(*[body(t, size) for t in texts]).arrange(DOWN, buff=buff, aligned_edge=LEFT)


def caption(mob, text, direction=DOWN, buff=0.25, size=LABEL_SIZE, color=LABEL):
    """A small grey label next to an object."""
    return T(text, size, color).next_to(mob, direction, buff=buff)


def formula(tex, symbols=None, size=FORMULA_SIZE):
    """A formula with one fixed colour per symbol: formula(r"W_2 = W_1 - F + 1", {"W_2": BLUE, "F": YELLOW})."""
    return MathTex(tex, font_size=size, tex_to_color_map=symbols or {})


def fit(mob, max_width=12.6, max_height=6.4):
    """Scale an object down (never up) so it fits inside the given box."""
    k = min(max_width / mob.width if mob.width else 1, max_height / mob.height if mob.height else 1, 1)
    return mob.scale(k)


# ---------------------------------------------------------------- grids
def grid(values, cell=CELL, border=GUIDE, num_color=INK, shade=False, show_numbers=True, fmt="{:g}"):
    """Grid of squares, one per value. Each cell is VGroup(square[, number]); cells are in row order.
    shade=True fills each cell by value (0 = black, 1 = white)."""
    rows, cols = len(values), len(values[0])
    cells = VGroup()
    for r in range(rows):
        for c in range(cols):
            v = values[r][c]
            sq = Square(cell, stroke_color=border, stroke_width=2)
            if shade:
                sq.set_fill(interpolate_color(BLACK, WHITE, min(max(float(v), 0.0), 1.0)), opacity=1)
            cg = VGroup(sq)
            if show_numbers:
                cg.add(MathTex(fmt.format(v), font_size=CELL_NUM_SIZE, color=num_color).move_to(sq))
            cells.add(cg)
    cells.arrange_in_grid(rows, cols, buff=0)
    return cells


def pixel_grid(values, vmax, cell=CELL):
    """Data grid: each cell filled grey by value/vmax, with its number in a readable colour."""
    cells = VGroup()
    for row in values:
        for v in row:
            level = float(v) / vmax
            sq = Square(cell, stroke_color=GUIDE, stroke_width=2).set_fill(interpolate_color(BLACK, WHITE, level), opacity=1)
            num = MathTex(f"{v:g}", font_size=CELL_NUM_SIZE, color=BLACK if level > 0.55 else WHITE).move_to(sq)
            cells.add(VGroup(sq, num))
    cells.arrange_in_grid(len(values), len(values[0]), buff=0)
    return cells


def tex_grid(labels, border=GUIDE, color=INK, cell=0.9, size=30):
    """Grid of cells holding MathTex strings (labels is a 2D list)."""
    cells = VGroup()
    for row in labels:
        for s in row:
            sq = Square(cell, stroke_color=border, stroke_width=2)
            cells.add(VGroup(sq, MathTex(str(s), font_size=size, color=color).move_to(sq)))
    cells.arrange_in_grid(len(labels), len(labels[0]), buff=0)
    return cells


def signed_grid(values, cell=CELL, size=CELL_NUM_SIZE, fmt="{:g}", border=TOOL):
    """A tool's grid (kernel, weight matrix): entries blue if positive, red if negative, white if zero."""
    g = tex_grid([[fmt.format(v) for v in row] for row in values], border=border, cell=cell, size=size)
    for c, v in zip(g, [v for row in values for v in row]):
        c[1].set_color(POS if v > 0 else NEG if v < 0 else INK)
    return g


def blank_grid(rows, cols, cell=CELL, fill=GREY_D, opacity=0.55, border=GUIDE):
    """Grid of plain cells (no numbers)."""
    g = VGroup(*[Square(cell, stroke_color=border, stroke_width=2).set_fill(fill, opacity=opacity) for _ in range(rows * cols)])
    g.arrange_in_grid(rows, cols, buff=0)
    return g


def gray_map(arr, cell=0.4, vmax=None):
    """2D data as grey cells, no numbers: 0 = black, vmax = white."""
    vmax = float(vmax if vmax is not None else max(abs(float(v)) for row in arr for v in row) or 1)
    g = VGroup(*[Square(cell, stroke_color=GUIDE, stroke_width=1).set_fill(
        interpolate_color(BLACK, WHITE, min(max(float(v) / vmax, 0), 1)), opacity=1) for row in arr for v in row])
    g.arrange_in_grid(len(arr), len(arr[0]), buff=0)
    return g


def signed_map(arr, cell=0.4):
    """2D signed data as cells: blue = positive, red = negative, strength = opacity."""
    vmax = max(abs(float(v)) for row in arr for v in row) or 1
    g = VGroup(*[Square(cell, stroke_color=GUIDE, stroke_width=1).set_fill(
        POS if v >= 0 else NEG, opacity=abs(float(v)) / vmax) for row in arr for v in row])
    g.arrange_in_grid(len(arr), len(arr[0]), buff=0)
    return g


def window_at(g, cols, r, c, f=2, color=TOOL):
    """A square outline over the f x f block of grid g (which has `cols` columns) whose top-left cell is (r, c)."""
    block = VGroup(g[r * cols + c], g[(r + f - 1) * cols + c + f - 1])
    return Square(g[0][0].width * f, stroke_color=color, stroke_width=6).move_to(block.get_center())


# ---------------------------------------------------------------- flows, volumes, networks
def flow_boxes(texts, size=LABEL_SIZE, buff=0.7, color=DIM):
    """A row of boxed steps joined by arrows. Returns (group, boxes, arrows)."""
    boxes = VGroup()
    for t in texts:
        label = T(t, size, SOFT)
        boxes.add(VGroup(SurroundingRectangle(label, color=color, buff=0.2, stroke_width=2), label))
    boxes.arrange(RIGHT, buff=buff)
    arrows = VGroup(*[Arrow(a.get_right(), b.get_left(), buff=0.08, stroke_width=4, color=LABEL,
                            max_tip_length_to_length_ratio=0.25) for a, b in zip(boxes, boxes[1:])])
    return VGroup(boxes, arrows), boxes, arrows


def arrow_between(a, b, buff=0.25, color=LABEL):
    return Arrow(a.get_right(), b.get_left(), buff=buff, stroke_width=4, color=color, max_tip_length_to_length_ratio=0.2)


def sheets(side, depth, colors, border=GUIDE, step=0.18, opacity=0.35, width=2):
    """A volume drawn as `depth` stacked square sheets (a flat stand-in for 3D). The last item is the front sheet."""
    s = VGroup()
    for i in reversed(range(depth)):
        s.add(Square(side, stroke_color=border, stroke_width=width).set_fill(colors[i % len(colors)], opacity=opacity)
              .shift((RIGHT + UP) * step * i))
    return s


def neuron(activation=0.0, radius=NEURON_R):
    """A neuron: white outline, fill brightness = activation (0..1)."""
    return Circle(radius, stroke_color=INK, stroke_width=2).set_fill(
        interpolate_color(BLACK, WHITE, min(max(float(activation), 0.0), 1.0)), opacity=1)


def layer(activations, gap=0.45):
    """A vertical column of neurons."""
    return VGroup(*[neuron(a) for a in activations]).arrange(DOWN, buff=gap - 2 * NEURON_R)


def connect(left, right, weights=None, max_width=3):
    """Lines between two layers. weights[i][j] (right i, left j) sets colour by sign and width/opacity by size."""
    lines = VGroup()
    for i, r in enumerate(right):
        for j, l in enumerate(left):
            w = 1.0 if weights is None else float(weights[i][j])
            lines.add(Line(l.get_right(), r.get_left(), stroke_color=POS if w >= 0 else NEG,
                           stroke_width=max(0.5, min(abs(w), 1) * max_width), stroke_opacity=0.25 + 0.75 * min(abs(w), 1)))
    return lines


def plot(fn, x_range, y_range, color=RESULT, width=6.0, height=3.6, x_label=None, y_label=None):
    """Axes with one curve. Returns (group, axes, curve); add more curves with axes.plot(...)."""
    ax = Axes(x_range=x_range, y_range=y_range, x_length=width, y_length=height, tips=False,
              axis_config={"color": LABEL, "stroke_width": 2, "include_numbers": True, "font_size": 22})
    curve = ax.plot(fn, color=color, stroke_width=4)
    g = VGroup(ax, curve)
    if x_label:
        g.add(caption(ax, x_label, DOWN, 0.2))
    if y_label:
        g.add(T(y_label, LABEL_SIZE, LABEL).next_to(ax, LEFT, buff=0.2).rotate(PI / 2))
    return g, ax, curve


def picture(path, height=4.6, label=None):
    """A source figure or photo shown as is, with a grey label under it. Returns Group(image[, label])."""
    img = ImageMobject(str(path)).scale_to_fit_height(height)
    g = Group(img)
    if label:
        g.add(T(label, LABEL_SIZE, LABEL).next_to(img, DOWN, buff=0.15))
    return g
