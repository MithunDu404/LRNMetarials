#!/usr/bin/env python
"""mv.py: command line for the manim-video skill. Standard library only; run it with any Python 3.10+.

    python mv.py check                          what this machine has (Manim, LaTeX, ffmpeg, voices)
    python mv.py new <video> [source file]      make the video folder from the templates, ingest the source
    python mv.py script <video>                 script.py -> script.json + SCRIPT_REVIEW.md, coverage check
    python mv.py voice <video> [--engine kokoro|sarvam] [--voice NAME] [--speed X] [--lang CODE] [--only s1,s2]
    python mv.py scene <video> <scene...|all> [-ql|-qm|-qh] [-j N]     render + contact sheet + warnings
    python mv.py join <video>                   join final renders, loudness -14 LUFS, one .srt per part
    python mv.py status <video>                 per scene: lines, voiced, preview, final

<video> is the video's folder (for example ~/Videos/manim-video/cnn). It finds the right Python for each job by
itself: this one, ./.venv, the notebook-video venv, and any listed under "pythons" in
~/.config/manim-video/config.json (or the file named by MANIM_VIDEO_CONFIG).
"""
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SK = Path(__file__).resolve().parent
HOME = Path.home()
QUALITY = {"-ql": ("480p15", []), "-qm": ("720p30", []), "-qh": ("1080p30", ["--fps", "30"])}


# ------------------------------------------------------------------ finding tools
def config():
    p = Path(os.environ.get("MANIM_VIDEO_CONFIG", HOME / ".config" / "manim-video" / "config.json"))
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def venv_python(d):
    return Path(d) / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def pythons():
    cands = [sys.executable, *config().get("pythons", []), venv_python(Path.cwd() / ".venv"),
             venv_python(HOME / ".cache" / "notebook-video" / "venv")]
    out = []
    for c in map(str, cands):
        if Path(c).exists() and c not in out:
            out.append(c)
    return out


_found = {}


def find_python(*mods):
    """First known Python that has all the named packages (checked without importing them)."""
    if mods not in _found:
        code = "import importlib.util as u,sys;sys.exit(0 if all(u.find_spec(m) for m in sys.argv[1:]) else 1)"
        _found[mods] = next((py for py in pythons()
                             if subprocess.run([py, "-c", code, *mods], capture_output=True).returncode == 0), None)
    return _found[mods]


def kokoro_dir():
    for d in [config().get("kokoro_dir"), os.environ.get("KOKORO_DIR"), HOME / ".cache" / "notebook-video",
              HOME / ".cache" / "manim-video", SK / "models"]:
        if d and (Path(d) / "kokoro-v1.0.onnx").exists() and (Path(d) / "voices-v1.0.bin").exists():
            return Path(d)
    return None


def sarvam_env(video=None):
    """Path of the .env file that holds SARVAM_API_KEY, or "" when the key is already in the environment. None = not found."""
    if os.environ.get("SARVAM_API_KEY"):
        return ""
    for p in [config().get("sarvam_env"), Path.cwd() / ".env", *([video / ".env", video.parent / ".env"] if video else [])]:
        if p and Path(p).exists() and re.search(r"^\s*SARVAM_API_KEY\s*=\s*\S", Path(p).read_text(encoding="utf-8", errors="replace"), re.M):
            return str(p)
    return None


def run(cmd, **kw):
    return subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)


def duration(path):
    return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).stdout)


def class_name(scene):
    return "".join(p.capitalize() for p in scene.split("_"))


def load_script(video):
    return json.loads((video / "script.json").read_text(encoding="utf-8"))


# ------------------------------------------------------------------ check
def cmd_check(_):
    ok = True
    py = find_python("manim")
    if py:
        ver = run([py, "-c", "import importlib.metadata as m;print(m.version('manim'))"]).stdout.strip()
        pango = run([py, "-c", "import manimpango"]).returncode == 0
        print(f"manim     OK   {ver}   {py}")
        print("pango     OK" if pango else "pango     BLOCKED  (fine: render.py works around it; use Tex/MathTex/T(), never Text() or Code)")
    else:
        ok = False
        print("manim     MISSING  (no known Python has the manim package)")
    for t in ("latex", "dvisvgm", "ffmpeg", "ffprobe"):
        w = shutil.which(t)
        print(f"{t:<9} {'OK   ' + w if w else 'MISSING'}")
        ok = ok and (bool(w) or t in ("latex", "dvisvgm"))
    if not shutil.which("latex"):
        print("          without LaTeX there are no formulas: T() falls back to plain text, MathTex fails")
    kp, kd = find_python("kokoro_onnx", "soundfile", "numpy"), kokoro_dir()
    print(f"kokoro    {'OK   ' + kp + '   models: ' + str(kd) if kp and kd else 'MISSING  (package: ' + str(bool(kp)) + ', model files: ' + str(bool(kd)) + ')'}")
    sp, se = find_python("sarvamai", "dotenv"), sarvam_env()
    print(f"sarvam    {'OK   ' + sp + '   key: found' if sp and se is not None else 'not ready  (package: ' + str(bool(sp)) + ', key: ' + ('found' if se is not None else 'not found') + ')'}")
    ip = find_python("pymupdf", "markitdown")
    print(f"ingest    {'OK   ' + ip if ip else 'text files only  (PDF/PPTX/DOCX need pymupdf + markitdown)'}")
    print("READY" if ok else "NOT READY: tell the user what is missing; do not install anything without their OK")
    return 0 if ok else 1


# ------------------------------------------------------------------ new
def cmd_new(args):
    video = Path(args[0]).expanduser().resolve()
    for d in ("source", "scenes", "audio", "out"):
        (video / d).mkdir(parents=True, exist_ok=True)
    for f in (SK.parent / "templates").iterdir():
        dst = video / ("scenes" if f.name == "topic.py" else "") / f.name
        if not dst.exists() and f.name != "scene_example.py":
            shutil.copy(f, dst)
    print("video folder:", video)
    for src in map(Path, args[1:]):
        ext = src.suffix.lower()
        if ext in (".md", ".txt", ".markdown"):
            shutil.copy(src, video / "source" / src.name)
            text = src.read_text(encoding="utf-8", errors="replace")
            print(f"source: {video / 'source' / src.name} ({len(text.split())} words, {len(text.splitlines())} lines)")
            for link in dict.fromkeys(re.findall(r"!\[[^\]]*\]\(([^)\s]+)", text)):
                img = (src.parent / link.replace("%20", " ")).resolve()
                if img.exists():
                    dst = video / "source" / link.replace("%20", " ")
                    if not dst.resolve().is_relative_to(video / "source"):
                        dst = video / "source" / "figures" / img.name
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy(img, dst)
                    print("figure:", dst)
                else:
                    print("figure NOT FOUND:", link)
        else:
            py = find_python("pymupdf", "markitdown")
            if not py:
                print(f"cannot ingest {src.name}: no Python with pymupdf + markitdown")
                return 1
            shutil.copy(src, video / "source" / src.name)
            r = run([py, SK / "ingest.py", src, video / "source", "60"])
            print(r.stdout + r.stderr)
    return 0


# ------------------------------------------------------------------ script
def cmd_script(args):
    video = Path(args[0]).expanduser().resolve()
    ns = runpy.run_path(str(video / "script.py"))
    scenes, title = ns["SCENES"], ns.get("TITLE", video.name)
    cov_file = video / "COVERAGE.md"
    known = re.findall(r"^\|\s*(C\d+)\s*\|", cov_file.read_text(encoding="utf-8"), re.M) if cov_file.exists() else []
    out, review, used, problems = {}, [f"# Script review: {title}", ""], {}, []
    n_lines = chars = words = added = fixes = 0
    for scene, lines in scenes.items():
        if not re.fullmatch(r"[a-z][a-z0-9_]*", scene):
            problems.append(f"scene name {scene!r}: use lowercase letters, digits and _ only")
        out[scene], ids_scene, rows = [], [], []
        for i, ln in enumerate(lines, 1):
            ln = (ln,) if isinstance(ln, str) else tuple(ln)
            text, visual, ids, flag = (ln + ("", "", ""))[:4]
            spoken, sub = (text, None) if isinstance(text, str) else text
            spoken = " ".join(spoken.split())
            item = {"id": f"l{i:02d}", "text": spoken}
            if sub:
                item["sub"] = " ".join(sub.split())
            out[scene].append(item)
            if len(spoken) > 1500:
                problems.append(f"{scene}/l{i:02d}: longer than 1,500 characters, split it")
            if len(spoken.split()) > 70:
                problems.append(f"{scene}/l{i:02d}: {len(spoken.split())} words in one line; split where the picture changes")
            for cid in ids.replace(",", " ").split():
                used.setdefault(cid, []).append(scene)
                ids_scene.append(cid)
            n_lines += 1; chars += len(spoken); words += len(spoken.split())
            added += flag == "added"; fixes += flag == "fix"
            mark = {"added": " **[added]**", "fix": " **[source correction]**"}.get(flag, "")
            rows.append(f"| l{i:02d} | {spoken.replace('|', '/')}{mark}" + (f"<br>*subtitle:* {sub.replace('|', '/')}" if sub else "")
                        + f" | {visual.replace('|', '/')} | {ids} |")
        w = sum(len(x["text"].split()) for x in out[scene])
        review += [f"## {scene}", "", f"Coverage: {' '.join(dict.fromkeys(ids_scene)) or '-'} · about {w / 150:.1f} min", "",
                   "| Line | Narration | Planned visual | IDs |", "|---|---|---|---|", *rows, ""]
    missing = [c for c in known if c not in used]
    unknown = [c for c in used if known and c not in known]
    if missing:
        problems.append(f"{len(missing)} coverage IDs are in no line: {' '.join(missing)}")
    if unknown:
        problems.append(f"IDs used in the script but not in COVERAGE.md: {' '.join(unknown)}")
    summary = (f"{len(scenes)} scenes, {n_lines} lines, {words} words, {chars} characters. About {words / 150:.1f} min at 150 words "
               f"per minute. {added} [added] lines, {fixes} source corrections. Sarvam estimate: about Rs {chars / 1000:.1f} "
               f"(Rs 1 per 1,000 characters; Kokoro is free).")
    review[2:2] = [summary, ""]
    (video / "script.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    (video / "SCRIPT_REVIEW.md").write_text("\n".join(review), encoding="utf-8")
    print(summary)
    print(f"coverage: {len(known) - len(missing)}/{len(known)} IDs referenced" if known else "coverage: no COVERAGE.md table found")
    for p in problems:
        print("PROBLEM", p)
    print("SCRIPT OK" if not problems else f"{len(problems)} problems")
    return 1 if problems else 0


# ------------------------------------------------------------------ voice
def cmd_voice(args):
    video = Path(args[0]).expanduser().resolve()
    engine = args[args.index("--engine") + 1] if "--engine" in args else "kokoro"
    extra = []
    if engine == "kokoro":
        py, kd = find_python("kokoro_onnx", "soundfile", "numpy"), kokoro_dir()
        if not (py and kd):
            print("Kokoro is not available here (package or model files missing). Run `mv.py check` and tell the user.")
            return 1
        extra = ["--kokoro-dir", kd]
    elif engine == "sarvam":
        py, env = find_python("sarvamai", "dotenv"), sarvam_env(video)
        if not py or env is None:
            print("Sarvam is not ready (sarvamai package or SARVAM_API_KEY in a .env file missing). Tell the user; never ask for the key in chat.")
            return 1
        extra = ["--env", env] if env else []
    else:
        print("engine must be kokoro or sarvam")
        return 1
    return subprocess.run([py, str(SK / "voice.py"), str(video), *args[1:], *map(str, extra)]).returncode


# ------------------------------------------------------------------ scene
def render_one(py, video, scene, quality):
    folder, extra = QUALITY[quality]
    cls = class_name(scene)
    r = run([py, SK / "render.py", quality, *extra, "--media_dir", video / "media", video / "scenes" / f"{scene}.py", cls], cwd=video)
    mp4 = video / "media" / "videos" / scene / folder / f"{cls}.mp4"
    log = r.stdout + r.stderr
    warns = list(dict.fromkeys(l.strip() for l in log.splitlines() if l.startswith("MV-WARN")))
    if r.returncode != 0 or not mp4.exists():
        tail = [l for l in log.splitlines() if l.strip() and not l.startswith("MV-WARN")][-16:]
        return scene, False, f"FAILED {scene}\n" + "\n".join(tail)
    dur = duration(mp4)
    sheet = video / "out" / "sheets" / f"{scene}.png"
    sheet.parent.mkdir(parents=True, exist_ok=True)
    run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf", f"fps=16/{dur:.3f},scale=640:-1,tile=4x4", "-frames:v", "1", sheet])
    voiced = sum(v["seconds"] for k, v in json.loads((video / "audio" / "voice.json").read_text(encoding="utf-8")).items()
                 if k.split("/")[0] == scene)
    msg = f"OK {scene}: {dur:.1f} s ({voiced:.1f} s of speech) -> {sheet}"
    if dur > voiced * 1.6 + 6:
        msg += "\n  NOTE long silent stretches: check the scene is not waiting with nothing said"
    return scene, True, msg + "".join(f"\n  {w}" for w in warns[:12]) + (f"\n  ... {len(warns) - 12} more warnings" if len(warns) > 12 else "")


def cmd_scene(args):
    video = Path(args[0]).expanduser().resolve()
    quality = next((a for a in args if a in QUALITY), "-ql")
    jobs = int(args[args.index("-j") + 1]) if "-j" in args else 1
    names = [a for i, a in enumerate(args[1:], 1) if not a.startswith("-") and args[i - 1] != "-j"]
    script = load_script(video)
    if names == ["all"]:
        names = list(script)
    py = find_python("manim")
    if not py:
        print("no Python with manim found: run `mv.py check`")
        return 1
    bad = [n for n in names if not (video / "scenes" / f"{n}.py").exists()]
    if bad:
        print("no scene file for:", " ".join(bad))
        return 1
    failed = []
    with ThreadPoolExecutor(max(jobs, 1)) as ex:
        for scene, ok, msg in ex.map(lambda n: render_one(py, video, n, quality), names):
            print(msg, flush=True)
            if not ok:
                failed.append(scene)
    print(f"{len(names) - len(failed)}/{len(names)} scenes rendered at {QUALITY[quality][0]}" + (f"; failed: {' '.join(failed)}" if failed else ""))
    return 1 if failed else 0


# ------------------------------------------------------------------ join
def srt_time(s):
    h, m, rest = s.split(":")
    return int(h) * 3600 + int(m) * 60 + float(rest.replace(",", "."))


def srt_fmt(t):
    ms = round(t * 1000)
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def cmd_join(args):
    video = Path(args[0]).expanduser().resolve()
    scenes = list(load_script(video))
    parts = {}
    for s in scenes:
        m = re.match(r"p(\d+)_", s)
        parts.setdefault(m.group(1) if m else "", []).append(s)
    out = video / "out"
    out.mkdir(exist_ok=True)
    for part, names in parts.items():
        files = [video / "media" / "videos" / s / "1080p30" / f"{class_name(s)}.mp4" for s in names]
        missing = [s for s, f in zip(names, files) if not f.exists()]
        if missing:
            print("no final render (-qh) for:", " ".join(missing))
            return 1
        for s, f in zip(names, files):
            if f.stat().st_mtime < (video / "scenes" / f"{s}.py").stat().st_mtime:
                print(f"WARNING {s}: the scene file is newer than its final render")
        lst = out / f"list{'_p' + part if part else ''}.txt"
        lst.write_text("".join(f"file '{f.as_posix()}'\n" for f in files), encoding="utf-8")
        target = out / f"{video.name}{'_part' + part if part else ''}.mp4"
        r = run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c:v", "copy",
                 "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000", "-c:a", "aac", "-b:a", "192k", target])
        if r.returncode != 0:
            print(r.stderr[-800:])
            return 1
        cues, offset = [], 0.0
        for f in files:
            srt = f.with_suffix(".srt")
            if srt.exists():
                for block in re.split(r"\n\s*\n", srt.read_text(encoding="utf-8").strip()):
                    ls = block.splitlines()
                    if len(ls) >= 3 and "-->" in ls[1]:
                        a, b = [srt_time(x.strip()) + offset for x in ls[1].split("-->")]
                        cues.append((a, b, "\n".join(ls[2:])))
            offset += duration(f)
        target.with_suffix(".srt").write_text(
            "".join(f"{i}\n{srt_fmt(a)} --> {srt_fmt(b)}\n{t}\n\n" for i, (a, b, t) in enumerate(cues, 1)), encoding="utf-8")
        total = duration(target)
        loud = re.findall(r"I:\s+(-?[\d.]+) LUFS", run(["ffmpeg", "-i", target, "-af", "ebur128", "-f", "null", "-"]).stderr)
        print(f"{target}: {int(total // 60)}:{int(total % 60):02d}, {len(files)} scenes, {len(cues)} subtitle cues, "
              f"sum of scenes {offset:.1f} s, loudness {loud[-1] if loud else '?'} LUFS, {target.stat().st_size / 2**20:.0f} MiB")
    return 0


# ------------------------------------------------------------------ status
def cmd_status(args):
    video = Path(args[0]).expanduser().resolve()
    script = load_script(video)
    vp = video / "audio" / "voice.json"
    voice = json.loads(vp.read_text(encoding="utf-8")) if vp.exists() else {}
    print(f"{'scene':<28} lines voiced  speech  built  preview final")
    for s, lines in script.items():
        v = [voice[f"{s}/{l['id']}"] for l in lines if voice.get(f"{s}/{l['id']}", {}).get("text") == l["text"]]
        base = video / "media" / "videos" / s
        mark = lambda q: "yes" if (base / q / f"{class_name(s)}.mp4").exists() else "-"
        print(f"{s:<28} {len(lines):>5} {len(v):>6} {sum(x['seconds'] for x in v):>6.0f}s  "
              f"{'yes' if (video / 'scenes' / f'{s}.py').exists() else '-':<6} {mark('480p15'):<7} {mark('1080p30')}")
    return 0


if __name__ == "__main__":
    cmds = {"check": cmd_check, "new": cmd_new, "script": cmd_script, "voice": cmd_voice, "scene": cmd_scene,
            "join": cmd_join, "status": cmd_status}
    if len(sys.argv) < 2 or sys.argv[1] not in cmds or (sys.argv[1] != "check" and len(sys.argv) < 3):
        print(__doc__)
        sys.exit(2)
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    sys.exit(cmds[sys.argv[1]](sys.argv[2:]))
