# voice.py: turn <video>/script.json into <video>/audio/<scene>/<id>.wav + <video>/audio/voice.json.
# Run through `mv.py voice` (it picks a Python that has the engine's packages). Only new or changed lines are voiced.
#   engine kokoro: offline and free (kokoro-onnx + its two model files)
#   engine sarvam: paid API (sarvamai SDK; key read from a .env file, never printed)
import argparse
import json
import os
import subprocess
import sys
import wave
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("video")
ap.add_argument("--engine", default="kokoro")
ap.add_argument("--voice", default="")
ap.add_argument("--speed", type=float, default=0)
ap.add_argument("--lang", default="")
ap.add_argument("--only", default="")
ap.add_argument("--kokoro-dir", default="")
ap.add_argument("--env", default="")
ap.add_argument("--spend-ok", action="store_true")
a = ap.parse_args()

video = Path(a.video).resolve()
script = json.loads((video / "script.json").read_text(encoding="utf-8"))
index_path = video / "audio" / "voice.json"
index = json.loads(index_path.read_text(encoding="utf-8")) if index_path.exists() else {}
only = [s for s in a.only.split(",") if s]

KOKORO_LANG = {"a": "en-us", "b": "en-gb", "h": "hi", "e": "es", "f": "fr-fr", "i": "it", "p": "pt-br"}
if a.engine == "kokoro":
    voice = a.voice or "af_heart"
    speed = a.speed or (1.0 if voice.startswith("h") else 0.8)     # 0.8 is a calm teaching pace for the English voices
    lang = a.lang or KOKORO_LANG.get(voice[0], "en-us")
else:
    voice, speed, lang = a.voice or "shubh_en_narration", a.speed or 1.1, a.lang or "en-IN"
sig = f"{a.engine}|{voice}|{speed}|{lang}"

todo = []
for scene, lines in script.items():
    if only and scene not in only:
        continue
    for line in lines:
        key, text = f"{scene}/{line['id']}", line["text"].strip()
        wav = video / "audio" / scene / f"{line['id']}.wav"
        if wav.exists() and index.get(key, {}).get("text") == text and index[key].get("sig") == sig:
            if index[key].get("sub") != line.get("sub"):            # subtitle text changed: no new audio needed
                index[key]["sub"] = line.get("sub")
            continue
        todo.append((key, text, line.get("sub"), wav))
chars = sum(len(t) for _, t, _, _ in todo)
print(f"to voice: {len(todo)} lines, {chars} characters, engine {a.engine}, voice {voice}, speed {speed}, language {lang}", flush=True)
if a.engine == "sarvam" and todo and not a.spend_ok:
    print(f"STOPPED before spending: about Rs {chars / 1000:.1f} at Rs 1 per 1,000 characters (check the current price). "
          f"Ask the user, then re-run with --spend-ok.")
    sys.exit(2)


def save(key, text, sub, wav):
    with wave.open(str(wav)) as w:
        index[key] = {"seconds": round(w.getnframes() / w.getframerate(), 3), "text": text, "sig": sig}
    if sub:
        index[key]["sub"] = sub
    index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"{key}: {index[key]['seconds']} s", flush=True)


def to_wav(data, wav, fmt=None):
    """Any audio bytes -> 48 kHz mono wav."""
    wav.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", *(["-f", fmt] if fmt else []), "-i", "-", "-ac", "1", "-ar", "48000",
                    str(wav)], input=data, check=True)


if todo and a.engine == "kokoro":
    import io
    import re
    import numpy as np
    import soundfile as sf
    from kokoro_onnx import Kokoro
    d = Path(a.kokoro_dir)
    k = Kokoro(str(d / "kokoro-v1.0.onnx"), str(d / "voices-v1.0.bin"))
    for key, text, sub, wav in todo:
        chunks = []
        for sn in [p for p in re.split(r'(?<=[.!?।])\s+', text) if p]:      # sentence by sentence, short gap between
            audio, sr = k.create(sn, voice=voice, speed=speed, lang=lang)
            nz = np.where(np.abs(audio) > 0.004)[0]
            if len(nz):
                audio = audio[max(0, nz[0] - 240): nz[-1] + 480]
            chunks += [audio, np.zeros(int(0.3 * sr), np.float32)]
        buf = io.BytesIO()
        sf.write(buf, np.concatenate(chunks[:-1]), sr, format="WAV")
        to_wav(buf.getvalue(), wav)
        save(key, text, sub, wav)
elif todo and a.engine == "sarvam":
    from dotenv import load_dotenv
    from sarvamai import SarvamAI
    if a.env:
        load_dotenv(a.env)
    client = SarvamAI(api_subscription_key=os.environ["SARVAM_API_KEY"])
    for key, text, sub, wav in todo:
        assert len(text) <= 1500, f"{key} is longer than 1,500 characters; split it"
        mp3 = b"".join(client.text_to_speech.convert_stream(
            text=text, language_code=lang, speaker=voice, model="bulbul:v4-flash",
            pace=speed, speech_sample_rate=24000, output_audio_codec="mp3"))
        to_wav(mp3, wav)
        save(key, text, sub, wav)
elif todo:
    sys.exit(f"unknown engine {a.engine}")

index_path.parent.mkdir(parents=True, exist_ok=True)
index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")
total = sum(v["seconds"] for kk, v in index.items() if kk.split("/")[0] in script)
words = sum(len(v["text"].split()) for kk, v in index.items() if kk.split("/")[0] in script)
print(f"VOICE OK: {total / 60:.1f} min of speech in voice.json, about {words / max(total, 1) * 60:.0f} words per minute")
