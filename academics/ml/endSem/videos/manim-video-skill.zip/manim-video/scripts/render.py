# render.py: start Manim with the skill's library on the import path.
# Used by `mv.py scene`; direct use:  python render.py -ql --media_dir <video>/media <video>/scenes/<name>.py <Class>
# Manim imports ManimPango (system-font text) at start-up. Where that library cannot load (for example Windows
# Smart App Control blocks its DLL), a stand-in is registered so everything else works; scenes then use LaTeX
# text only (Tex / MathTex / the kit's T()), never Text() or Code.
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
for a in sys.argv[1:]:
    if a.endswith(".py"):
        sys.path.insert(0, str(Path(a).resolve().parent))      # so scenes can import a topic.py beside them

try:
    import manimpango  # noqa: F401
except Exception:
    from unittest.mock import MagicMock
    for k in [k for k in sys.modules if k.split(".")[0] == "manimpango"]:
        del sys.modules[k]
    sys.modules["manimpango"] = MagicMock(name="manimpango stand-in (Text/Code unavailable)")
    os.environ["MV_NO_PANGO"] = "1"

from manim.__main__ import main  # noqa: E402

if __name__ == "__main__":
    main()
