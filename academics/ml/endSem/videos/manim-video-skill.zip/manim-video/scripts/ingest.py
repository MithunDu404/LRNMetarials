"""Turn a source file into text + page images you can look at.

    python ingest.py <file> <outdir> [dpi=40]

PDF  -> outdir/text.md (layout text per page) + outdir/pages/p001.png ...
PPTX -> converted to PDF first (PowerPoint via COM on Windows, else LibreOffice `soffice`), then as PDF;
        text also via markitdown (keeps speaker notes)
DOCX/HTML/MD/other -> outdir/text.md via markitdown
Prints the paths so they can be opened with Read in batches.
"""
import os, shutil, subprocess, sys


def pptx_to_pdf(src, outdir):
    pdf = os.path.join(outdir, os.path.splitext(os.path.basename(src))[0] + ".pdf")
    if os.name == "nt":
        ps = (f"$p = New-Object -ComObject PowerPoint.Application; "
              f"$d = $p.Presentations.Open('{os.path.abspath(src)}', $true, $false, $false); "
              f"$d.SaveAs('{os.path.abspath(pdf)}', 32); $d.Close(); $p.Quit()")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
        if os.path.exists(pdf): return pdf
        print("PowerPoint export failed:", r.stderr.strip()[:300])
    so = shutil.which("soffice") or shutil.which("libreoffice")
    if so:
        subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir", outdir, src], check=True)
        if os.path.exists(pdf): return pdf
    print("No PowerPoint or LibreOffice: slide images unavailable, text only (figures may be missed!)")
    return None


def pdf_pages(pdf, outdir, dpi):
    import pymupdf
    os.makedirs(os.path.join(outdir, "pages"), exist_ok=True)
    doc = pymupdf.open(pdf); txt = []
    for i, page in enumerate(doc, 1):
        page.get_pixmap(dpi=dpi).save(os.path.join(outdir, "pages", f"p{i:03d}.png"))
        txt.append(f"\n\n## page {i}\n\n" + page.get_text("text", sort=True))
    return len(doc), "".join(txt)


def markitdown(src):
    from markitdown import MarkItDown
    return MarkItDown().convert(src).text_content


def main():
    src, outdir = sys.argv[1], sys.argv[2]
    dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 40
    os.makedirs(outdir, exist_ok=True)
    ext = os.path.splitext(src)[1].lower()
    text, n = "", 0
    if ext in (".pptx", ".ppt"):
        text = markitdown(src)
        pdf = pptx_to_pdf(src, outdir)
        if pdf: n, _ = pdf_pages(pdf, outdir, dpi)
    elif ext == ".pdf":
        n, text = pdf_pages(src, outdir, dpi)
    else:
        text = markitdown(src)
    with open(os.path.join(outdir, "text.md"), "w", encoding="utf-8") as f: f.write(text)
    print("text:", os.path.join(outdir, "text.md"), f"({len(text.split())} words)")
    if n: print("pages:", os.path.join(outdir, "pages"), f"p001.png .. p{n:03d}.png ({n} images)")


if __name__ == "__main__":
    main()
